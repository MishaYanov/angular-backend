import { IsNotEmpty, IsNumber, IsOptional, Min } from "class-validator";

export class cartItemDto{
    
    @IsNumber()
    @IsOptional()
    id?: number;

    @IsNumber()
    @IsNotEmpty()
    @Min(1)
    quantity: number;

    @IsNumber()
    @IsNotEmpty()
    itemId: number;

    @IsNumber()
    @IsNotEmpty()
    cartId: number;

}