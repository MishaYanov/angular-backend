import { Controller, Delete, Get, Post, UseGuards } from '@nestjs/common';
import { JwtGuard } from 'src/auth/guard/jwt.guard';
import { CartService } from './cart.service';

@UseGuards(JwtGuard)
@Controller('cart')
export class CartController {
    constructor(private cartService: CartService) {
}
    @Get('cart/:id')
    getCartByUserId() {}

    @Post('cart')
    addCart() {}

    @Post('cart/:id')
    updateCart() {}

    @Delete('cart/:id')
    deleteCart() {}
}
